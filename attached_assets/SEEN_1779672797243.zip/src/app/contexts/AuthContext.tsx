import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { projectId, publicAnonKey } from '/utils/supabase/info';
import type { UserRole, Language, UserIntent } from './StoryStateContext';

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-2bdc05e6`;

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  language: Language;
  intent: UserIntent;
  createdAt?: string;
  updatedAt?: string;
}

interface AuthState {
  user: User | null;
  accessToken: string | null;
  isLoading: boolean;
  isAuthenticated: boolean;
}

interface AuthContextType {
  state: AuthState;
  signUp: (email: string, password: string, name: string, role: UserRole, language: Language, intent: UserIntent) => Promise<void>;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  checkSession: () => Promise<void>;
  updateProfile: (updates: Partial<User>) => Promise<void>;
  requestRoleElevation: (requestedRole: UserRole, reason: string) => Promise<void>;
  requestPasswordRecovery: (email: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const AUTH_STORAGE_KEY = 'seenos_auth_session';

// ---------------------------------------------------------------------------
// JWT helpers — decode the payload WITHOUT a network call
// ---------------------------------------------------------------------------

/** Decode a JWT payload (base64url) into a plain object. Never throws. */
function decodeJwtPayload(token: string): Record<string, unknown> | null {
  try {
    const base64 = token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/');
    const json = decodeURIComponent(
      atob(base64)
        .split('')
        .map(c => '%' + c.charCodeAt(0).toString(16).padStart(2, '0'))
        .join('')
    );
    return JSON.parse(json);
  } catch {
    return null;
  }
}

/**
 * Returns true if the JWT has not expired yet (with a 60-second safety margin).
 * If the token cannot be decoded it is treated as expired.
 */
function isTokenStillValid(token: string): boolean {
  const payload = decodeJwtPayload(token);
  if (!payload || typeof payload.exp !== 'number') return false;
  return payload.exp * 1000 > Date.now() + 60_000; // 60 s safety margin
}

// ---------------------------------------------------------------------------
// Resilient fetch wrapper
// ---------------------------------------------------------------------------

/**
 * Thin fetch wrapper that converts low-level TypeError ("Failed to fetch")
 * into a user-friendly message. No retry — a single proxy failure is enough;
 * retrying doubles the number of errors surfaced in Figma's devtools worker.
 */
async function apiFetch(url: string, options: RequestInit): Promise<Response> {
  try {
    return await fetch(url, options);
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    if (
      msg.toLowerCase().includes('failed to fetch') ||
      msg.toLowerCase().includes('networkerror') ||
      msg.toLowerCase().includes('load failed')
    ) {
      throw new Error(
        'Unable to reach the SEEN server. Please check your internet connection and try again.'
      );
    }
    throw err;
  }
}

// ---------------------------------------------------------------------------
// AuthProvider
// ---------------------------------------------------------------------------

export function AuthProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AuthState>({
    user: null,
    accessToken: null,
    isLoading: true,
    isAuthenticated: false,
  });

  /**
   * On mount: restore session from localStorage using LOCAL JWT decoding.
   * We deliberately do NOT make a network request here — doing so proxies a
   * fetch through Figma's devtools worker on every render, and any failure
   * surfaces as "TypeError: Failed to fetch" inside the worker's stack trace.
   *
   * If the locally-decoded token is still valid we trust it and restore the
   * full session without touching the network. The first real API call will
   * return 401 if the token was revoked server-side, at which point signOut
   * is called automatically.
   */
  useEffect(() => {
    const loadSession = () => {
      try {
        const stored = localStorage.getItem(AUTH_STORAGE_KEY);
        if (stored) {
          const { accessToken, user } = JSON.parse(stored);
          if (accessToken && user && isTokenStillValid(accessToken)) {
            setState({
              user,
              accessToken,
              isLoading: false,
              isAuthenticated: true,
            });
            return;
          }
        }
      } catch (err) {
        console.warn('[Auth] Failed to restore session from storage:', err);
      }

      // No valid stored session
      setState({
        user: null,
        accessToken: null,
        isLoading: false,
        isAuthenticated: false,
      });
    };

    loadSession();
  }, []);

  // Token refresh — runs every 50 minutes when authenticated
  useEffect(() => {
    if (!state.accessToken || !state.isAuthenticated) return;

    const refreshInterval = setInterval(async () => {
      try {
        const stored = localStorage.getItem(AUTH_STORAGE_KEY);
        if (!stored) return;

        const { refreshToken } = JSON.parse(stored);
        if (!refreshToken) return;

        console.log('[Auth] Refreshing session token…');

        const response = await apiFetch(`${API_BASE}/auth/refresh`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ refresh_token: refreshToken }),
        });

        if (response.ok) {
          const { session, user } = await response.json();

          setState(prev => ({ ...prev, user, accessToken: session.access_token }));

          localStorage.setItem(
            AUTH_STORAGE_KEY,
            JSON.stringify({
              accessToken: session.access_token,
              refreshToken: session.refresh_token,
              user,
            })
          );

          console.log('[Auth] Session refreshed successfully');
        } else {
          console.error('[Auth] Refresh returned non-OK, signing out…');
          await signOut();
        }
      } catch (err) {
        console.error('[Auth] Error refreshing session:', err);
      }
    }, 50 * 60 * 1000);

    return () => clearInterval(refreshInterval);
  }, [state.accessToken, state.isAuthenticated]); // eslint-disable-line react-hooks/exhaustive-deps

  // Persist / clear session in localStorage
  const persistSession = (
    accessToken: string | null,
    refreshToken: string | null,
    user: User | null
  ) => {
    if (accessToken && refreshToken && user) {
      localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify({ accessToken, refreshToken, user }));
    } else {
      localStorage.removeItem(AUTH_STORAGE_KEY);
    }
  };

  const signUp = async (
    email: string,
    password: string,
    name: string,
    role: UserRole,
    language: Language,
    intent: UserIntent
  ) => {
    try {
      const response = await apiFetch(`${API_BASE}/auth/signup`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${publicAnonKey}`,
        },
        body: JSON.stringify({ email, password, name, role, language, intent }),
      });

      const contentType = response.headers.get('content-type');
      let data: any;
      if (contentType?.includes('application/json')) {
        data = await response.json();
      } else {
        const text = await response.text();
        throw new Error(`Server returned non-JSON response: ${text.substring(0, 200)}`);
      }

      if (!response.ok) {
        if (data.code === 'email_exists' || response.status === 409) {
          const error = new Error(
            'An account with this email already exists. Please sign in instead.'
          );
          (error as any).code = 'email_exists';
          throw error;
        }
        throw new Error(data.error || data.details || `Signup failed with status ${response.status}`);
      }

      if (data.session && data.user) {
        setState({
          user: data.user,
          accessToken: data.session.access_token,
          isLoading: false,
          isAuthenticated: true,
        });
        persistSession(data.session.access_token, data.session.refresh_token, data.user);
      } else {
        // Account created but no immediate session — attempt sign-in
        await new Promise(resolve => setTimeout(resolve, 500));
        await signIn(email, password);
      }
    } catch (err) {
      console.error('[Auth] Error during signup:', err);
      throw err;
    }
  };

  const signIn = async (email: string, password: string) => {
    try {
      const response = await apiFetch(`${API_BASE}/auth/signin`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${publicAnonKey}`,
        },
        body: JSON.stringify({ email, password }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Sign in failed');
      }

      const { session, user } = data;

      setState({
        user,
        accessToken: session.access_token,
        isLoading: false,
        isAuthenticated: true,
      });

      persistSession(session.access_token, session.refresh_token, user);
    } catch (err) {
      console.error('[Auth] Error during sign in:', err);
      throw err;
    }
  };

  const signOut = async () => {
    try {
      if (state.accessToken) {
        await apiFetch(`${API_BASE}/auth/signout`, {
          method: 'POST',
          headers: { Authorization: `Bearer ${state.accessToken}` },
        });
      }
    } catch (err) {
      console.error('[Auth] Error during sign out:', err);
    } finally {
      setState({
        user: null,
        accessToken: null,
        isLoading: false,
        isAuthenticated: false,
      });
      persistSession(null, null, null);
      localStorage.removeItem('hasEnteredSEEN');
      localStorage.removeItem('onboarding_completed');
      localStorage.removeItem('onboarding_step');
    }
  };

  const checkSession = async () => {
    if (!state.accessToken) return;

    try {
      const response = await apiFetch(`${API_BASE}/auth/session`, {
        headers: { Authorization: `Bearer ${state.accessToken}` },
      });

      if (!response.ok) {
        await signOut();
        return;
      }

      const { user } = await response.json();
      setState(prev => ({ ...prev, user }));
    } catch (err) {
      console.error('[Auth] Error checking session:', err);
    }
  };

  const updateProfile = async (updates: Partial<User>) => {
    if (!state.accessToken) throw new Error('Not authenticated');

    try {
      const response = await apiFetch(`${API_BASE}/profile`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${state.accessToken}`,
        },
        body: JSON.stringify(updates),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to update profile');
      }

      setState(prev => ({ ...prev, user: data.profile }));
      persistSession(state.accessToken, null, data.profile);
    } catch (err) {
      console.error('[Auth] Error updating profile:', err);
      throw err;
    }
  };

  const requestRoleElevation = async (requestedRole: UserRole, reason: string) => {
    if (!state.accessToken) throw new Error('Not authenticated');

    try {
      const response = await apiFetch(`${API_BASE}/profile/request-role`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${state.accessToken}`,
        },
        body: JSON.stringify({ requestedRole, reason }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to request role elevation');
      }

      return data;
    } catch (err) {
      console.error('[Auth] Error requesting role elevation:', err);
      throw err;
    }
  };

  const requestPasswordRecovery = async (email: string) => {
    try {
      const response = await apiFetch(`${API_BASE}/auth/recovery`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${publicAnonKey}`,
        },
        body: JSON.stringify({ email }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to request password recovery');
      }

      return data;
    } catch (err) {
      console.error('[Auth] Error requesting password recovery:', err);
      throw err;
    }
  };

  return (
    <AuthContext.Provider
      value={{
        state,
        signUp,
        signIn,
        signOut,
        checkSession,
        updateProfile,
        requestRoleElevation,
        requestPasswordRecovery,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextType {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
